# Laravel_project
 This is my laravel first project. This is made following MVC pattern and only the work of the CRUD is done here.
