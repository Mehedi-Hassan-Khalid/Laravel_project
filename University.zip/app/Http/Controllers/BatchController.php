<?php

namespace App\Http\Controllers;

use App\Models\Batch;
use Illuminate\Http\Request;

class BatchController extends Controller
{
    public function batch_form(){
        return view('frontEnd.batch.batch_form');
    }

    public function manage_batch(Request $request){
        return view('frontEnd.batch.manage_batch',[
            'batches'=>Batch::all()
        ]);
    }

    public function add_batch(Request $request){

        Batch::newAddBatch($request);
        return back()->with('message','Successfully Created ');

        //dd($request);   // OR, return $request;
    }

    public function edit_batch($id){
        return view('frontEnd.batch.edit_batch',[
            'batches'=>Batch::find($id)
        ]);
    }

    public function update_batch(Request $request){
        Batch:: newUpdateBatch($request);
        return redirect(route('manage_batch'))->with('message','Updated Successfully');
    }

    public function delete_batch(Request $request){
        Batch::newDeleteBatch($request);
        return redirect(route('manage_batch'))->with('message','Deleted Successfully');
    }
}
