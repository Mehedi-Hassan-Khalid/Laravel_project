<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    public function course_form(){
        return view('frontEnd.course.course_form');
    }

    public function manage_course(Request $request){
        return view('frontEnd.course.manage_course',[
            'courses'=>Course::all()
        ]);
    }

    public function add_course(Request $request){

        Course::newAddCourse($request);
        return back()->with('message','Successfully Created ');

        //dd($request);   // OR, return $request;
    }

    public function edit_course($id){
        return view('frontEnd.course.edit_course',[
            'courses'=>Course::find($id)
        ]);
    }

    public function update_course(Request $request){
        course:: newUpdateCourse($request);
        return redirect(route('manage_course'))->with('message','Updated Successfully');
    }

    public function delete_course(Request $request){
        Course::newDeleteCourse($request);
        return redirect(route('manage_course'))->with('message','Deleted Successfully');
    }
}
