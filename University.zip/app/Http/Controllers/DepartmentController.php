<?php

namespace App\Http\Controllers;

use App\Models\Department;
use Illuminate\Http\Request;

class DepartmentController extends Controller
{
    public $department;

    public function department_form(){
        return view('frontEnd.department.department_form');
    }

    public function manage_department(){
        return view('frontEnd.department.manage_department',[
            'departments'=> Department::all()
        ]);
    }

    public function add_department(Request $request){

        Department::newAddDepartment($request);
        return back()->with('message','Successfully Created');

        //dd($request);   // OR, return $request;
    }

    public function edit_department($id){
        return view('frontEnd.department.edit_department',[
            'departments'=>Department::find($id)
        ]);
    }

    public function update_department(Request $request){
        Department::newUpdateDepartment($request);
        return redirect(route('manage_department'))->with('message','Updated Successfully');
    }

    public function delete_department(Request $request){
        Department::newDeleteDepartment($request);
        return redirect(route('manage_department'))->with('message4','Deleted Successfully');
    }
}
