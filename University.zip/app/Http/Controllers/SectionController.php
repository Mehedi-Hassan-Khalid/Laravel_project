<?php

namespace App\Http\Controllers;

use App\Models\Section;
use Illuminate\Http\Request;

class SectionController extends Controller
{
    public function section_form(){
        return view('frontEnd.section.section_form');
    }

    public function manage_section(Request $request){
        return view('frontEnd.section.manage_section',[
            'sections'=>Section::all()
        ]);
    }

    public function add_section(Request $request){

        Section::newAddSection($request);
        return back()->with('message','Successfully Created ');

        //dd($request);   // OR, return $request;
    }

    public function edit_section($id){
        return view('frontEnd.section.edit_section',[
            'sections'=>Section::find($id)
        ]);
    }

    public function update_section(Request $request){
        Section:: newUpdateSection($request);
        return redirect(route('manage_section'))->with('message','Updated Successfully');
    }

    public function delete_section(Request $request){
        Section::newDeleteSection($request);
        return redirect(route('manage_section'))->with('message','Deleted Successfully');
    }
}
