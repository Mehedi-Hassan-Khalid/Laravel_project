<?php

namespace App\Http\Controllers;

use App\Models\Batch;
use App\Models\Course;
use App\Models\Department;
use App\Models\Section;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public $student,$image,$imageName,$directory,$imageUrl;


    public function student_form(){
        return view('frontEnd.student.student_form',[
            'departments'=>Department::all(),
            'batches'=>Batch::all(),
            'sections'=>Section::all(),
            'courses'=>Course::all(),
        ]);
    }

    public function manage_student(){
        $this->student = DB::table('students')
            ->join('departments','students.dept_id','=','departments.id')
            ->join('batches','students.bat_id','=','batches.id')
            ->join('sections','students.sec_id','=','sections.id')
            ->join('courses','students.cour_id','=','courses.id')
            ->select('students.*','departments.department_name','departments.department_code',
                    'batches.batch_name','sections.section_name','courses.course_name',
                    'courses.course_title','courses.course_code','courses.course_credit')
            ->get();


        return view('frontEnd.student.manage_student',[
            'students'=>$this->student
        ]);
    }

    public function add_student(Request $request){

        Student::newAddStudent($request);
        return back()->with('message','Successfully Created ');
    }

    public function edit_student($id){
        return view('frontEnd.student.edit_student',[
            'students'=>Student::find($id),
            'departments'=>Department::all(),
            'batches'=>Batch::all(),
            'sections'=>Section::all(),
            'courses'=>Course::all(),
        ]);
    }

    public function update_student(Request $request){
        Student::newUpdateStudent($request);
        return redirect(route('manage_student'))->with('message','Successfully Updated');
    }

    public function delete_student(Request $request){
        Student::newDeleteStudent($request);
        return redirect(route('manage_student'))->with('message','Successfully Deleted');
    }
}
