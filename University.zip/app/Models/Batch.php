<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Batch extends Model
{
    use HasFactory;

    protected $fillable = ['batch_name'];     // Or, protected $guarded = [];

    protected static $batch;

    protected static function newAddBatch($request){
        self::$batch = new Batch();
        self::$batch->batch_name = $request->batch_name;
        self::$batch->save();
    }

    protected static function newUpdateBatch($request){
        self::$batch = Batch::find($request->batch_id);
        self::$batch->batch_name = $request->batch_name;
        self::$batch->save();
    }

    protected static function newDeleteBatch($request){
        self::$batch = Batch::find($request->batch_id);
        self::$batch->delete();
    }
}
