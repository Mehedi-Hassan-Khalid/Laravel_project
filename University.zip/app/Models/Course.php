<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
    use HasFactory;

    protected $fillable = ['course_name, course_title, course_code, course_credit'];     // Or, protected $guarded = [];

    protected static $course;

    protected static function newAddCourse($request){
        self::$course = new Course();
        self::$course->course_name = $request->course_name;
        self::$course->course_title = $request->course_title;
        self::$course->course_code = $request->course_code;
        self::$course->course_credit = $request->course_credit;
        self::$course->save();
    }

    protected static function newUpdateCourse($request){
        self::$course = Course::find($request->course_id);
        self::$course->course_name = $request->course_name;
        self::$course->course_title = $request->course_title;
        self::$course->course_code = $request->course_code;
        self::$course->course_credit = $request->course_credit;
        self::$course->save();
    }

    protected static function newDeleteCourse($request){
        self::$course = Course::find($request->course_id);
        self::$course->delete();
    }
}
