<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;

    protected $fillable = ['department_name,department_code'];     // Or, protected $guarded = [];

    protected static $department;

    protected static function newAddDepartment($request){
        self::$department = new Department();
        self::$department->department_name = $request->department_name;
        self::$department->department_code = $request->department_code;

        self::$department->save();
    }

    protected static function newUpdateDepartment($request){
        self::$department = Department::find($request->department_id);

        self::$department->department_name = $request->department_name;
        self::$department->department_code = $request->department_code;
        self::$department->save();
    }

    protected static function newDeleteDepartment($request){
        self::$department = Department::find($request->department_id);
        self::$department->delete();
    }

}
