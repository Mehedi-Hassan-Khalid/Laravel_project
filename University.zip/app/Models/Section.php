<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    use HasFactory;

    protected $fillable = ['section_name'];     // Or, protected $guarded = [];

    protected static $section;

    protected static function newAddSection($request){
        self::$section = new Section();
        self::$section->section_name = $request->section_name;
        self::$section->save();
    }

    protected static function newUpdateSection($request){
        self::$section = Section::find($request->section_id);
        self::$section->section_name = $request->section_name;
        self::$section->save();
    }

    protected static function newDeleteSection($request){
        self::$section = Section::find($request->section_id);
        self::$section->delete();
    }
}
