<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    use HasFactory;

    protected $fillable = ['student_id','name','phone','email,','dept_id','bat_id','sec_id','cour_id','address','image'];

    protected static $student,$image,$imageName,$directory,$imageUrl;

    protected static function newAddStudent($request){
        self::$student = new Student();
        self::$student->student_id = $request->student_id;
        self::$student->name = $request->name;
        self::$student->phone = $request->phone;
        self::$student->email = $request->email;
        self::$student->dept_id = $request->dept_id;
        self::$student->bat_id = $request->bat_id;
        self::$student->sec_id = $request->sec_id;
        self::$student->cour_id = $request->cour_id;
        self::$student->address = $request->address;
        self::$student->image = self::getUrlImage($request);
        self::$student->save();
    }

    protected static function getUrlImage($request){
        self::$image      = $request->file('image');
        self::$imageName  = rand().'.'.self::$image->getClientOriginalExtension();
        self::$directory  = 'asset/images/';
        self::$imageUrl   = self::$directory.self::$imageName;
        self::$image->move(self::$directory,self::$imageName);
        return self::$imageUrl;
    }

    protected static function newUpdateStudent($request){
        self::$student = Student::find($request->std_id);
        self::$student->student_id = $request->student_id;
        self::$student->name = $request->name;
        self::$student->phone = $request->phone;
        self::$student->email = $request->email;
        self::$student->dept_id = $request->dept_id;
        self::$student->bat_id = $request->bat_id;
        self::$student->sec_id = $request->sec_id;
        self::$student->cour_id = $request->cour_id;
        self::$student->address = $request->address;
        if ($request->file('image')){
            if (self::$student->image !=null){
                unlink(self::$student->image);
            }
            self::$student->image = self::getUrlImage($request);
        }

        self::$student->save();
    }

    protected static function newDeleteStudent($request){
        self::$student = Student::find($request->std_id);
        if (file_exists(self::$student->image)){
            unlink(self::$student->image);
        }
        self::$student->delete();
    }
}
