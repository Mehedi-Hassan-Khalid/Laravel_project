<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
            $table->id();
            $table->string('student_id');
            $table->string('name');
            $table->string('phone');
            $table->string('email')->nullable(); // this column is null
            $table->integer('dept_id')->comment('This id is "primary ID" of the "departments" table');
            $table->integer('bat_id')->comment('This id is "primary ID" of the "Batches" table');;
            $table->integer('sec_id')->comment('This id is "primary ID" of the "Sections" table');;
            $table->integer('cour_id')->comment('This id is "primary ID" of the "Courses" table');;
            $table->text('address');
            $table->text('image');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}
