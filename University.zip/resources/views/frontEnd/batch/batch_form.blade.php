@extends('frontEnd.master')

@section('title')
    Add Batch From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2>{{ session('message') }}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Add Batch Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('add_batch') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="md-3">
                                    <label for="" class="form-label">Batch Name</label>
                                    <input type="text" name="batch_name" class="form-control" placeholder="Batch Name">
                                </div>

                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
@endsection






