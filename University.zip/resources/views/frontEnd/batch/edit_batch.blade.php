@extends('frontEnd.master')

@section('title')
    Edit Batch From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Edit Batch Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('update_batch') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" value="{{ $batches->id }}" name="batch_id">
                                <div class="md-3">
                                    <label for="" class="form-label">Batch Name</label>
                                    <input type="text" value="{{ $batches->batch_name }}" name="batch_name" class="form-control" placeholder="Batch Name">
                                </div>

                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Saves as">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
@endsection






