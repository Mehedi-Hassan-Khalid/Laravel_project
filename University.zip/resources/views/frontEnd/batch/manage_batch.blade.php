@extends('frontEnd.master')

@section('title')
    Batch Manage Table
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h1>{{ session('message') }}</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Batch Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Batch Name</th>
                                    <th>Action</th>
                                </tr>
                                @foreach($batches as $batch)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $batch->batch_name }}</td>
                                        <td>
                                            <a href="{{ route('edit_batch',['id'=>$batch->id]) }}" class="btn btn-primary">Edit</a>

                                            <form action="{{ route('delete_batch') }}" method="post">
                                                @csrf
                                                <input type="hidden" name="batch_id" value="{{ $batch->id }}">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection






