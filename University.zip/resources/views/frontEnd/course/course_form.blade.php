@extends('frontEnd.master')

@section('title')
    Add Course From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2>{{ session('message') }}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Add Course Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('add_course') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="md-3">
                                    <label for="" class="form-label">Course Name</label>
                                    <input type="text" name="course_name" class="form-control" placeholder="course Name">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Title</label>
                                    <input type="text" name="course_title" class="form-control" placeholder="course Title">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Code</label>
                                    <input type="text" name="course_code" class="form-control" placeholder="course Code">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Credit</label>
                                    <input type="text" name="course_credit" class="form-control" placeholder="course Credit">
                                </div>
                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            </div>
        </div>
    </section>
@endsection






