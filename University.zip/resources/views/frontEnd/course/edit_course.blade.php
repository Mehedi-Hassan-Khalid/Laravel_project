@extends('frontEnd.master')

@section('title')
    Edit Course From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Edit Course Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('update_course') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" value="{{ $courses->id }}" name="course_id">

                                <div class="md-3">
                                    <label for="" class="form-label">Course Name</label>
                                    <input type="text" value="{{ $courses->course_name }}" name="course_name" class="form-control" placeholder="Course Name">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Title</label>
                                    <input type="text" value="{{ $courses->course_title }}" name="course_title" class="form-control" placeholder="Course Title">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Code</label>
                                    <input type="text" value="{{ $courses->course_code }}" name="course_code" class="form-control" placeholder="Course Code">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Course Credit</label>
                                    <input type="text" value="{{ $courses->course_credit }}" name="course_credit" class="form-control" placeholder="Course Credit">
                                </div>
                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Saves as">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection






