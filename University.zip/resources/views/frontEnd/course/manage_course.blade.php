@extends('frontEnd.master')

@section('title')
    Course Manage Table
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2>{{ session('message') }}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Course Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Course Name</th>
                                    <th>Course Title</th>
                                    <th>Course Code</th>
                                    <th>Course Credit</th>
                                    <th>Action</th>
                                </tr>
                                @foreach($courses as $course)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $course->course_name }}</td>
                                        <td>{{ $course->course_title }}</td>
                                        <td>{{ $course->course_code }}</td>
                                        <td>{{ $course->course_credit }}</td>
                                        <td>
                                            <a href="{{ route('edit_course',['id'=>$course->id]) }}" class="btn btn-primary">Edit</a>

                                            <form action="{{ route('delete_course') }}" method="post">
                                                @csrf
                                                <input type="hidden" name="course_id" value="{{ $course->id }}">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection






