@extends('frontEnd.master')

@section('title')
    Home
@endsection

@section('content')
    <section class="university">
        <div class="container">
            <img src="{{ asset('asset/Image/university.jfif') }}" alt="Our University Campus">
            <div class="row">
                <div class="col-md-12">

                </div>
            </div>
        </div>
    </section>
@endsection





