<!--NavBar Section-->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container">
        <a href="{{ route('home') }}" class="navbar-brand">
            <img src="{{ asset('asset/Image/logo.png') }}" class="img-fluid" width="100px" alt="Our website logo">
        </a>

        <ul class="navbar-nav">
            <li>
                <a href="{{ route('home') }}" class="nav-link">Home</a>
            </li>

            <li>
                <a href="{{ route('student') }}" class="nav-link">Add student</a>
            </li>

            <li>
                <a href="{{ route('manage_student') }}" class="nav-link">Manage Student</a>
            </li>

            <li>
                <a href="{{ route('batch') }}" class="nav-link">Add Batch</a>
            </li>

            <li>
                <a href="{{ route('manage_batch') }}" class="nav-link">Manage Batch</a>
            </li>

            <li>
                <a href="{{ route('section') }}" class="nav-link">Add Section</a>
            </li>

            <li>
                <a href="{{ route('manage_section') }}" class="nav-link">Manage Section</a>
            </li>

            <li>
                <a href="{{ route('department') }}" class="nav-link">Add Department</a>
            </li>

            <li>
                <a href="{{ route('manage_department') }}" class="nav-link">Manage Department</a>
            </li>

            <li>
                <a href="{{ route('course') }}" class="nav-link">Add Course</a>
            </li>

            <li>
                <a href="{{ route('manage_course') }}" class="nav-link">Manage Course</a>
            </li>

        </ul>
    </div>
</nav>
