@extends('frontEnd.master')

@section('title')
    Edit Section From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Edit Section Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('update_section') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" value="{{ $sections->id }}" name="section_id">

                                <div class="md-3">
                                    <label for="" class="form-label">Section Name</label>
                                    <input type="text" value="{{ $sections->section_name }}" name="section_name" class="form-control" placeholder="Section Name">
                                </div>
                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Saves as">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
@endsection






