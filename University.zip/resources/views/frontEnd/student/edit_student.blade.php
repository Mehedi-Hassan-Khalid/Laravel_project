@extends('frontEnd.master')

@section('title')
    Edit Student From
@endsection

@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2>{{ session('message') }}</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Edit Student Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="{{ route('update_student') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" value="{{ $students->id }}" name="std_id">
                                <div class="md-3">
                                    <label for="" class="form-label">Student ID</label>
                                    <input type="text" value="{{ $students->student_id }}" name="student_id" class="form-control" placeholder="Student ID">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Name</label>
                                    <input type="text" value="{{ $students->name }}" name="name" class="form-control" placeholder="Student Name">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Phone</label>
                                    <input type="text" value="{{ $students->phone }}" name="phone" class="form-control" placeholder="Phone">
                                </div>


                                <div class="md-3">
                                    <label for="" class="form-label">Email</label>
                                    <input type="email" value="{{ $students->email }}" name="email" class="form-control" placeholder="Email">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Dept_id</label>
                                    <select name="dept_id" id="" class="form-control">
                                        <option  selected>Selected Department</option>
                                        @foreach($departments as $department)
                                            <option value="{{ $department->id }}">{{ $department->department_name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Bat_id</label>
                                    <select name="bat_id" id="" class="form-control">
                                        <option value="" selected>Selected Batch</option>
                                        @foreach($batches as $batch)
                                            <option value="{{ $batch->id }}">{{ $batch->batch_name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Sec_id</label>
                                    <select name="sec_id" id="" class="form-control">
                                        <option value="" selected>Selected Section</option>
                                        @foreach($sections as $section)
                                            <option value="{{ $section->id }}">{{ $section->section_name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Cour_id</label>
                                    <select name="cour_id" id="" class="form-control">
                                        <option value="" selected>Selected Course</option>
                                        @foreach($courses as $course)
                                            <option value="{{ $course->id }}">{{ $course->course_name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Address</label>
                                    <textarea name="address" class="form-control" id="" cols="30" rows="10">{{ $students->address }}</textarea>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Image</label>
                                    <input type="file" name="image" class="form-control">
                                    <img src="{{ asset($students->image) }}" class="img-fluid" alt="">
                                </div>

                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Saves as">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection








