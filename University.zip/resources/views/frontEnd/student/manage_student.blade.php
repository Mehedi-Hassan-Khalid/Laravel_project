@extends('frontEnd.master')

@section('title')
    Student Manage Table
@endsection
@section('content')
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Student Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Dept_Name</th>
                                    <th>Dept_Code</th>
                                    <th>Bat_Name</th>
                                    <th>Sec_Name</th>
                                    <th>Cour_Name</th>
                                    <th>Cour_Title</th>
                                    <th>Cour_Code</th>
                                    <th>Cour_Credit</th>
                                    <th>Address</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                @foreach($students as $student)
                                    <tr>
                                        <td>{{ $loop->iteration }}</td>
                                        <td>{{ $student->student_id }}</td>
                                        <td>{{ $student->name }}</td>
                                        <td>{{ $student->phone }}</td>
                                        <td>{{ $student->email }}</td>
                                        <td>{{ $student->department_name }}</td>
                                        <td>{{ $student->department_code }}</td>
                                        <td>{{ $student->batch_name }}</td>
                                        <td>{{ $student->section_name }}</td>
                                        <td>{{ $student->course_name }}</td>
                                        <td>{{ $student->course_title }}</td>
                                        <td>{{ $student->course_code }}</td>
                                        <td>{{ $student->course_credit }}</td>
                                        <td>{{ $student->address }}</td>
                                        <td>
                                            <img src="{{ asset($student->image) }}" class="img-fluid" width="100px" alt="">
                                        </td>

                                        <td>
                                            <a href="{{ route('edit_student',['id'=>$student->id]) }}" class="btn btn-primary">Edit</a>

                                            <form action="{{ route('delete_student') }}" method="post">
                                                @csrf
                                                <input type="hidden" name="std_id" value="{{ $student->id }}">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                @endforeach
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection







