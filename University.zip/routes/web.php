<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\BatchController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[HomeController::class,'index'])->name('home');

Route::get('/student',[StudentController::class,'student_form'])->name('student');
Route::get('/manage_student',[StudentController::class,'manage_student'])->name('manage_student');
Route::post('/add_student',[StudentController::class,'add_student'])->name('add_student');
Route::get('/edit_student/{id}',[StudentController::class,'edit_student'])->name('edit_student');
Route::post('/update_student',[StudentController::class,'update_student'])->name('update_student');
Route::post('/delete_student',[StudentController::class,'delete_student'])->name('delete_student');


Route::get('/batch',[BatchController::class,'batch_form'])->name('batch');
Route::get('/manage_batch',[BatchController::class,'manage_batch'])->name('manage_batch');
Route::post('/add_batch',[BatchController::class,'add_batch'])->name('add_batch');
Route::get('/edit_batch/{id}',[BatchController::class,'edit_batch'])->name('edit_batch');
Route::post('/update_batch',[BatchController::class,'update_batch'])->name('update_batch');
Route::post('/delete_batch',[BatchController::class,'delete_batch'])->name('delete_batch');

Route::get('/section',[SectionController::class,'section_form'])->name('section');
Route::get('/manage_section',[SectionController::class,'manage_section'])->name('manage_section');
Route::post('/add_section',[SectionController::class,'add_section'])->name('add_section');
Route::get('/edit_section/{id}',[SectionController::class,'edit_section'])->name('edit_section');
Route::post('/update_section',[SectionController::class,'update_section'])->name('update_section');
Route::post('/delete_section',[SectionController::class,'delete_section'])->name('delete_section');


Route::get('/department',[DepartmentController::class,'department_form'])->name('department');
Route::get('/manage_department',[DepartmentController::class,'manage_department'])->name('manage_department');
Route::post('/add_department',[DepartmentController::class,'add_department'])->name('add_department');
Route::get('/edit_department/{id}',[DepartmentController::class,'edit_department'])->name('edit_department');
Route::post('/update_department',[DepartmentController::class,'update_department'])->name('update_department');
Route::post('/delete_department',[DepartmentController::class,'delete_department'])->name('delete_department');


Route::get('/course',[CourseController::class,'course_form'])->name('course');
Route::get('/manage_course',[CourseController::class,'manage_course'])->name('manage_course');
Route::post('/add_course',[CourseController::class,'add_course'])->name('add_course');
Route::get('/edit_course/{id}',[CourseController::class,'edit_course'])->name('edit_course');
Route::post('/update_course',[CourseController::class,'update_course'])->name('update_course');
Route::post('/delete_course',[CourseController::class,'delete_course'])->name('delete_course');



