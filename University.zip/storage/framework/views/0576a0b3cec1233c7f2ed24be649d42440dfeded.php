<?php $__env->startSection('title'); ?>
    Batch Manage Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e(session('message')); ?></h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Batch Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Batch Name</th>
                                    <th>Action</th>
                                </tr>
                                <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($batch->batch_name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit_batch',['id'=>$batch->id])); ?>" class="btn btn-primary">Edit</a>

                                            <form action="<?php echo e(route('delete_batch')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="batch_id" value="<?php echo e($batch->id); ?>">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/batch/manage_batch.blade.php ENDPATH**/ ?>