<?php $__env->startSection('title'); ?>
    Add Student From
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(session('message')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Add Student Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('add_student')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="md-3">
                                    <label for="" class="form-label">Student ID</label>
                                    <input type="text" name="student_id" class="form-control" placeholder="Student ID">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Name</label>
                                    <input type="text" name="name" class="form-control" placeholder="Student Name">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Phone</label>
                                    <input type="text" name="phone" class="form-control" placeholder="Phone">
                                </div>


                                <div class="md-3">
                                    <label for="" class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" placeholder="Email">
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Dept_id</label>
                                    <select name="dept_id" id="" class="form-control">
                                        <option  selected>Selected Department</option>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Bat_id</label>
                                    <select name="bat_id" id="" class="form-control">
                                        <option value="" selected>Selected Batch</option>
                                        <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $batch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($batch->id); ?>"><?php echo e($batch->batch_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Sec_id</label>
                                    <select name="sec_id" id="" class="form-control">
                                        <option value="" selected>Selected Section</option>
                                        <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($section->id); ?>"><?php echo e($section->section_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Cour_id</label>
                                    <select name="cour_id" id="" class="form-control">
                                        <option value="" selected>Selected Course</option>
                                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($course->id); ?>"><?php echo e($course->course_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Address</label>
                                    <textarea name="address" class="form-control" id="" cols="30" rows="10"></textarea>
                                </div>

                                <div class="md-3">
                                    <label for="" class="form-label">Image</label>
                                    <input type="file" name="image" class="form-control">
                                </div>

                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/student/student_form.blade.php ENDPATH**/ ?>