<?php $__env->startSection('title'); ?>
    Student Manage Table
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Student Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Student ID</th>
                                    <th>Name</th>
                                    <th>Phone</th>
                                    <th>Email</th>
                                    <th>Dept_Name</th>
                                    <th>Dept_Code</th>
                                    <th>Bat_Name</th>
                                    <th>Sec_Name</th>
                                    <th>Cour_Name</th>
                                    <th>Cour_Title</th>
                                    <th>Cour_Code</th>
                                    <th>Cour_Credit</th>
                                    <th>Address</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($student->id); ?></td>
                                        <td><?php echo e($student->student_id); ?></td>
                                        <td><?php echo e($student->name); ?></td>
                                        <td><?php echo e($student->phone); ?></td>
                                        <td><?php echo e($student->email); ?></td>
                                        <td><?php echo e($student->department_name); ?></td>
                                        <td><?php echo e($student->department_code); ?></td>
                                        <td><?php echo e($student->batch_name); ?></td>
                                        <td><?php echo e($student->section_name); ?></td>
                                        <td><?php echo e($student->course_name); ?></td>
                                        <td><?php echo e($student->course_title); ?></td>
                                        <td><?php echo e($student->course_code); ?></td>
                                        <td><?php echo e($student->course_credit); ?></td>
                                        <td><?php echo e($student->address); ?></td>












                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/student/manage_student.blade.php ENDPATH**/ ?>