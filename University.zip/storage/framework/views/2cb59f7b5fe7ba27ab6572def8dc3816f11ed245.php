<?php $__env->startSection('title'); ?>
    Edit Department From
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Edit Department Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('update_department')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($departments->id); ?>" name="department_id">
                                <div class="md-3">
                                    <label for="" class="form-label">Department Name</label>
                                    <input type="text" value="<?php echo e($departments->department_name); ?>" name="department_name" class="form-control" placeholder="Department Name">
                                </div>
                                <div class="md-3">
                                    <label for="" class="form-label">Department Code</label>
                                    <input type="text" value="<?php echo e($departments->department_code); ?>" name="department_code" class="form-control" placeholder="Department Code">
                                </div>
                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Saves as">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/department/edit_department.blade.php ENDPATH**/ ?>