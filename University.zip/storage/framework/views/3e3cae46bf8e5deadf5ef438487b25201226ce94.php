<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!--CSS Link-->
    <link rel="stylesheet" href="<?php echo e(asset('asset/CSS/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('asset/CSS/style.css')); ?>">
</head>
<body>

    <!-- ======= Header ======= -->
    <?php echo $__env->make('frontEnd.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main">

        <?php echo $__env->yieldContent('content'); ?>

    </main><!-- End #main -->



    <!-- ======= Footer ======= -->
    <?php echo $__env->make('frontEnd.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--JavaScript Link-->
    <script src="<?php echo e(asset('asset/JavaScript/bootstrap.bundle.min.js')); ?>"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/master.blade.php ENDPATH**/ ?>