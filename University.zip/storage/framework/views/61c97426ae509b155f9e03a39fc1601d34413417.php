<?php $__env->startSection('title'); ?>
    Department Manage Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(session('message')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Department Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Department Name</th>
                                    <th>Department Code</th>
                                    <th>Action</th>
                                </tr>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($department->department_name); ?></td>
                                        <td><?php echo e($department->department_code); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit_department',['id'=>$department->id])); ?>" class="btn btn-primary">Edit</a>

                                            <form action="<?php echo e(route('delete_department')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="department_id" value="<?php echo e($department->id); ?>">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/department/manage_department.blade.php ENDPATH**/ ?>