<!--NavBar Section-->
<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
    <div class="container">
        <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
            <img src="<?php echo e(asset('asset/Image/logo.png')); ?>" class="img-fluid" width="100px" alt="Our website logo">
        </a>

        <ul class="navbar-nav">
            <li>
                <a href="<?php echo e(route('home')); ?>" class="nav-link">Home</a>
            </li>

            <li>
                <a href="<?php echo e(route('student')); ?>" class="nav-link">Add student</a>
            </li>

            <li>
                <a href="<?php echo e(route('manage_student')); ?>" class="nav-link">Manage Student</a>
            </li>

            <li>
                <a href="<?php echo e(route('batch')); ?>" class="nav-link">Add Batch</a>
            </li>

            <li>
                <a href="<?php echo e(route('manage_batch')); ?>" class="nav-link">Manage Batch</a>
            </li>

            <li>
                <a href="<?php echo e(route('section')); ?>" class="nav-link">Add Section</a>
            </li>

            <li>
                <a href="<?php echo e(route('manage_section')); ?>" class="nav-link">Manage Section</a>
            </li>

            <li>
                <a href="<?php echo e(route('department')); ?>" class="nav-link">Add Department</a>
            </li>

            <li>
                <a href="<?php echo e(route('manage_department')); ?>" class="nav-link">Manage Department</a>
            </li>

            <li>
                <a href="<?php echo e(route('course')); ?>" class="nav-link">Add Course</a>
            </li>

            <li>
                <a href="<?php echo e(route('manage_course')); ?>" class="nav-link">Manage Course</a>
            </li>

        </ul>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/include/header.blade.php ENDPATH**/ ?>