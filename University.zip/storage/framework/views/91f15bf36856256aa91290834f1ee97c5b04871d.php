<?php $__env->startSection('title'); ?>
    Section Manage Table
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h1><?php echo e(session('message')); ?></h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Section Manage Table</h1>
                        </div>
                        <div class="card-body">
                            <table class="table table-striped">
                                <tr>
                                    <th>SL</th>
                                    <th>Section Name</th>
                                    <th>Action</th>
                                </tr>
                                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($section->section_name); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('edit_section',['id'=>$section->id])); ?>" class="btn btn-primary">Edit</a>

                                            <form action="<?php echo e(route('delete_section')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="section_id" value="<?php echo e($section->id); ?>">
                                                <button type="submit" onclick="return confirm('Are you sure delete this data?')" class="btn btn-danger">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/section/manage_section.blade.php ENDPATH**/ ?>