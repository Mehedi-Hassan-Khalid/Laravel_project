<!--JavaScript Link-->
<script src="<?php echo e(asset('asset/JavaScript/bootstrap.bundle.min.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/include/footer.blade.php ENDPATH**/ ?>