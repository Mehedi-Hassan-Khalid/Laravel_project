<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="university">
        <div class="container">
            <img src="<?php echo e(asset('asset/Image/university.jfif')); ?>" alt="Our University Campus">
            <div class="row">
                <div class="col-md-12">

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/home/home.blade.php ENDPATH**/ ?>