<?php $__env->startSection('title'); ?>
    Add Department From
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="form">
        <div class="container mt-5">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e(session('message')); ?></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 offset-md-2">
                    <div class="card mt-5">
                        <div class="card-header">
                            <h1>Add Department Form</h1>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('add_department')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="md-3">
                                    <label for="" class="form-label">Department Name</label>
                                    <input type="text" name="department_name" class="form-control" placeholder="Department Name">
                                </div>
                                <div class="md-3">
                                    <label for="" class="form-label">Department Code</label>
                                    <input type="text" name="department_code" class="form-control" placeholder="Department Code">
                                </div>
                                <div class="md-3 mt-2">
                                    <input type="submit" class="btn btn-primary form-control" value="Submit">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>







<?php echo $__env->make('frontEnd.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Program\PHP with Laravel Framework\server-1\htdocs\Laravel\HomeWork\University\resources\views/frontEnd/department/department_form.blade.php ENDPATH**/ ?>
